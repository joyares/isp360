﻿
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `isp360` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `isp360`;
DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `admin_user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partner_registration` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`admin_user_id`),
  UNIQUE KEY `uk_admin_users_username` (`username`),
  UNIQUE KEY `uk_admin_users_email` (`email`),
  KEY `idx_admin_users_role_id` (`role_id`),
  CONSTRAINT `fk_admin_users_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,1,'Mostafa Joy','joyares','$2y$10$6tPsk9vH6xDCvAmOzcJG.udvSPrA3/1cgKuEQriHS8vpOKEOt.saW','joyoares@gmail.com','01619649494','Default',1,1,NULL,NULL,'2026-04-19 20:48:53','2026-04-19 20:48:53');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_no` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registered_date` date NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `area` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_area` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `package_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `package_activate_date` date DEFAULT NULL,
  `package_expire_date` date DEFAULT NULL,
  `nid_other_documents` text COLLATE utf8mb4_unicode_ci,
  `deposit_money` decimal(12,2) NOT NULL DEFAULT '0.00',
  `connection_charge` decimal(12,2) NOT NULL DEFAULT '0.00',
  `assigned_devices` text COLLATE utf8mb4_unicode_ci,
  `support_ticket` text COLLATE utf8mb4_unicode_ci,
  `documents` text COLLATE utf8mb4_unicode_ci,
  `payment` text COLLATE utf8mb4_unicode_ci,
  `invoices` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `branch` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `uk_customers_username` (`username`),
  KEY `idx_customers_phone_no` (`phone_no`),
  KEY `idx_customers_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'test','01447455455','2026-04-19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,'2026-04-19 22:43:20','2026-04-19 22:43:20');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_categories` (
  `category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `uk_inventory_categories_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_categories` WRITE;
/*!40000 ALTER TABLE `inventory_categories` DISABLE KEYS */;
INSERT INTO `inventory_categories` VALUES (1,'Networking',10,1,'2026-04-24 19:41:59','2026-04-24 19:41:59'),(2,'Fiber Equipment',20,1,'2026-04-24 19:41:59','2026-04-24 19:41:59'),(3,'Accessories',30,1,'2026-04-24 19:41:59','2026-04-24 19:41:59'),(4,'Fiber Optics',0,1,'2026-04-24 20:10:30','2026-04-24 20:10:30');
/*!40000 ALTER TABLE `inventory_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_products` (
  `product_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `sub_category_id` bigint(20) unsigned NOT NULL,
  `unit_id` bigint(20) unsigned NOT NULL,
  `unit_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`product_id`),
  KEY `idx_inventory_products_category` (`category_id`),
  KEY `idx_inventory_products_sub_category` (`sub_category_id`),
  KEY `idx_inventory_products_unit` (`unit_id`),
  CONSTRAINT `fk_inventory_products_category` FOREIGN KEY (`category_id`) REFERENCES `inventory_categories` (`category_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_inventory_products_sub_category` FOREIGN KEY (`sub_category_id`) REFERENCES `inventory_sub_categories` (`sub_category_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_inventory_products_unit` FOREIGN KEY (`unit_id`) REFERENCES `inventory_units` (`unit_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_products` WRITE;
/*!40000 ALTER TABLE `inventory_products` DISABLE KEYS */;
INSERT INTO `inventory_products` VALUES (1,'Fiber Optics Test 1/4',4,3,3,0.00,1,'2026-04-24 22:28:07','2026-04-24 22:28:47');
/*!40000 ALTER TABLE `inventory_products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_serial_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_serial_numbers` (
  `serial_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint(20) unsigned NOT NULL,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `serial_ref` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`serial_id`),
  KEY `idx_serials_item` (`item_id`),
  KEY `idx_serials_invoice` (`invoice_id`),
  KEY `idx_serials_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_serial_numbers` WRITE;
/*!40000 ALTER TABLE `inventory_serial_numbers` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_serial_numbers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_stock_invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_stock_invoice_items` (
  `item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `brand` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `unit_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount_per_unit` decimal(12,2) NOT NULL DEFAULT '0.00',
  `warranty_period` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_subtotal` decimal(14,2) NOT NULL DEFAULT '0.00',
  `line_discount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(14,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`item_id`),
  KEY `idx_inv_items_invoice` (`invoice_id`),
  KEY `idx_inv_items_product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_stock_invoice_items` WRITE;
/*!40000 ALTER TABLE `inventory_stock_invoice_items` DISABLE KEYS */;
INSERT INTO `inventory_stock_invoice_items` VALUES (1,1,1,NULL,1,0.00,0.00,NULL,0.00,0.00,0.00,1,'2026-04-25 00:16:21');
/*!40000 ALTER TABLE `inventory_stock_invoice_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_stock_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_stock_invoices` (
  `invoice_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_id` bigint(20) unsigned NOT NULL,
  `invoice_date` date NOT NULL,
  `invoice_image` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `payment_mode` enum('cash','partial','emi') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `subtotal` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_discount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(14,2) NOT NULL DEFAULT '0.00',
  `due_days` int(11) DEFAULT NULL,
  `emi_count` int(11) DEFAULT NULL,
  `ref_employee` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`invoice_id`),
  UNIQUE KEY `uk_invoice_number` (`invoice_number`),
  KEY `idx_stock_invoices_vendor` (`vendor_id`),
  KEY `idx_stock_invoices_date` (`invoice_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_stock_invoices` WRITE;
/*!40000 ALTER TABLE `inventory_stock_invoices` DISABLE KEYS */;
INSERT INTO `inventory_stock_invoices` VALUES (1,'SINV-20260425-26439E',1,'2026-04-25',NULL,NULL,'cash',0.00,0.00,0.00,NULL,NULL,NULL,1,1,'2026-04-25 00:16:21','2026-04-25 00:16:21');
/*!40000 ALTER TABLE `inventory_stock_invoices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_stock_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_stock_payments` (
  `pay_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `due_date` date NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `payment_note` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pay_id`),
  KEY `idx_stock_payments_invoice` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_stock_payments` WRITE;
/*!40000 ALTER TABLE `inventory_stock_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_stock_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_sub_categories` (
  `sub_category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `sub_category_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sub_category_id`),
  UNIQUE KEY `uk_inventory_sub_categories_name` (`category_id`,`sub_category_name`),
  KEY `idx_inventory_sub_categories_category` (`category_id`),
  CONSTRAINT `fk_inventory_sub_categories_category` FOREIGN KEY (`category_id`) REFERENCES `inventory_categories` (`category_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_sub_categories` WRITE;
/*!40000 ALTER TABLE `inventory_sub_categories` DISABLE KEYS */;
INSERT INTO `inventory_sub_categories` VALUES (1,1,NULL,'Router',10,1,'2026-04-24 19:44:20','2026-04-24 19:44:20'),(2,1,NULL,'Switch',20,1,'2026-04-24 19:44:20','2026-04-24 19:44:20'),(3,4,3,'1/4',0,1,'2026-04-24 20:10:42','2026-04-24 22:27:55');
/*!40000 ALTER TABLE `inventory_sub_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_units` (
  `unit_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`unit_id`),
  UNIQUE KEY `uk_inventory_units_name` (`unit_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_units` WRITE;
/*!40000 ALTER TABLE `inventory_units` DISABLE KEYS */;
INSERT INTO `inventory_units` VALUES (1,'Pcs',10,1,'2026-04-24 19:41:59','2026-04-24 19:41:59'),(2,'Box',20,1,'2026-04-24 19:41:59','2026-04-24 19:41:59'),(3,'Meter',30,1,'2026-04-24 19:41:59','2026-04-24 19:41:59');
/*!40000 ALTER TABLE `inventory_units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_vendors` (
  `vendor_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`vendor_id`),
  UNIQUE KEY `uk_inventory_vendors_name` (`vendor_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_vendors` WRITE;
/*!40000 ALTER TABLE `inventory_vendors` DISABLE KEYS */;
INSERT INTO `inventory_vendors` VALUES (1,'ABC Supplies Ltd','Rahim','01711000001','contact@abcsupplies.com','Dhaka',10,1,'2026-04-24 22:32:28','2026-04-24 22:32:28'),(2,'XYZ Trading Co','Karim','01711000002','sales@xyztrading.com','Chattogram',20,1,'2026-04-24 22:32:28','2026-04-24 22:32:28');
/*!40000 ALTER TABLE `inventory_vendors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mycompany`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mycompany` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `partnerId` int(11) NOT NULL DEFAULT '0',
  `departmentId` int(11) NOT NULL DEFAULT '0',
  `roleId` int(11) NOT NULL DEFAULT '0',
  `parentId` int(11) NOT NULL DEFAULT '0',
  `branch_access_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `partner_access_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `firstname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` mediumtext COLLATE utf8mb4_unicode_ci,
  `user_type` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `avatar` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `logo_icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_main` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_phone` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_alt_phone` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_email` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mycompany_username` (`username`),
  KEY `idx_mycompany_enabled` (`enabled`),
  KEY `idx_mycompany_status` (`status`),
  KEY `idx_mycompany_deleted` (`deleted_at`),
  KEY `idx_mycompany_parent` (`parentId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mycompany` WRITE;
/*!40000 ALTER TABLE `mycompany` DISABLE KEYS */;
INSERT INTO `mycompany` VALUES (1,0,0,2,0,'0','0','company_1777049810_184','$2y$10$IfN594NZty9PLa2L.E5nvu4qeILAY4pGRNdlZcK7mZpyNtpO8q8x6',1,1,NULL,NULL,'info@friendsonline.com.bd','01710552641','Friends online BD','House#5, Kallyanpur Main road, Dhaka-1207','Mother ISP',1,'2026-04-24 22:56:50','2026-04-24 23:23:17',NULL,NULL,NULL,NULL,NULL,'assets/uploads/mycompany/icon_20260424172317_976f7bd4.png','assets/uploads/mycompany/main_20260424172317_bf4be9ae.png','Fairuz Islam Sohan','01710552641',NULL,'sohan.islam51@gmail.com');
/*!40000 ALTER TABLE `mycompany` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `partnerId` int(11) NOT NULL DEFAULT '0',
  `departmentId` int(11) NOT NULL DEFAULT '0',
  `roleId` int(11) NOT NULL DEFAULT '0',
  `parentId` int(11) NOT NULL DEFAULT '0',
  `branch_access_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `partner_access_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `firstname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` mediumtext COLLATE utf8mb4_unicode_ci,
  `user_type` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `avatar` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_partners_username` (`username`),
  KEY `idx_partners_enabled` (`enabled`),
  KEY `idx_partners_deleted` (`deleted_at`),
  KEY `idx_partners_parent` (`parentId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
INSERT INTO `partners` VALUES (1,0,0,2,0,'0','0','bestnet','$2y$10$/0KGnTC8/Fl.cau.jPME3eRDgvVpAiQOHWq0rxu1fMddKXHwhPAtO',1,'Bestnet',NULL,'bestnet@bestnet.com','01700000005','Bestnet','Shibganj, Bogura',NULL,1,'2026-04-21 21:03:26','2026-04-21 21:03:26',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `role_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_type` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_description` text COLLATE utf8mb4_unicode_ci,
  `menu_tree_json` json DEFAULT NULL,
  `role_slug` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uk_roles_role_slug` (`role_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super Daddy','super_admin','super admin','[\"index\", \"support_desk\", \"inventory\"]','super-daddy',1,'2026-04-19 19:40:17','2026-04-19 19:47:28'),(2,'Admin','super_admin','- roles,','[\"index\", \"support_desk\", \"all_tickets\", \"add_ticket\", \"ticket_mgmt\", \"card_view\", \"customers\", \"customer_details\", \"tickets_preview\", \"quick_links\", \"reports\", \"inventory\", \"vendors_suppliers\", \"product_categories\", \"products\", \"add_stock\", \"manage_stock\", \"inventory_locations\", \"stock_upload_history\", \"stock_items\", \"bulk_transfer\", \"transfer_history\", \"partners\", \"partner_mgmt\", \"partner_list\", \"add_partner\", \"deposit_reports\", \"payment_reports\", \"partner_wallet\", \"partner_settlement\", \"revenue_report\", \"share_price_mgmt\", \"renewal_report\", \"finance\", \"expense_management\", \"income_management\", \"category\", \"account_list\", \"transactions\", \"transfer\", \"hr_payroll\", \"proforma_invoices\", \"payment_history\", \"credit_debit_notes\", \"online_payments\", \"logs\", \"audit_logs\", \"login_history\", \"login_fail_attempts\", \"tickets_logs\", \"user_logs\", \"administration\", \"branches\", \"locations\", \"add_roles\", \"admin_users\", \"add_admin_user\", \"settings_html\"]','admin',1,'2026-04-19 19:58:24','2026-04-19 20:10:03'),(3,'Staff','staff','selected access','[\"index\", \"support_desk\", \"all_tickets\", \"add_ticket\", \"ticket_mgmt\", \"card_view\", \"customers\", \"customer_details\", \"tickets_preview\", \"quick_links\", \"reports\", \"inventory\", \"vendors_suppliers\", \"product_categories\", \"products\", \"add_stock\", \"manage_stock\", \"inventory_locations\", \"stock_upload_history\", \"stock_items\", \"bulk_transfer\", \"transfer_history\", \"finance\", \"expense_management\", \"income_management\", \"category\", \"account_list\", \"transactions\", \"transfer\", \"hr_payroll\", \"proforma_invoices\", \"payment_history\", \"credit_debit_notes\", \"online_payments\", \"logs\", \"audit_logs\", \"login_history\", \"login_fail_attempts\", \"tickets_logs\", \"user_logs\", \"administration\", \"branches\", \"locations\", \"roles\", \"add_roles\", \"admin_users\", \"add_admin_user\", \"settings_html\"]','staff',1,'2026-04-19 20:03:57','2026-04-19 20:06:57');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_ticket_branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket_branches` (
  `branch_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `branch_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`branch_id`),
  UNIQUE KEY `uk_support_ticket_branches_company_name` (`company_id`,`branch_name`),
  KEY `idx_support_ticket_branches_company` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_ticket_branches` WRITE;
/*!40000 ALTER TABLE `support_ticket_branches` DISABLE KEYS */;
INSERT INTO `support_ticket_branches` VALUES (1,1,'Main Branch',1,10,'2026-04-24 17:23:59','2026-04-24 17:23:59');
/*!40000 ALTER TABLE `support_ticket_branches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_ticket_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket_categories` (
  `category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `uk_support_ticket_categories_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_ticket_categories` WRITE;
/*!40000 ALTER TABLE `support_ticket_categories` DISABLE KEYS */;
INSERT INTO `support_ticket_categories` VALUES (1,'Net Slow',1,1,'2026-04-21 15:20:26','2026-04-21 19:34:10'),(2,'Technical Issue',1,20,'2026-04-21 15:20:26','2026-04-21 15:20:26'),(3,'Service Interruption',1,30,'2026-04-21 15:20:26','2026-04-21 15:20:26'),(4,'Installation',1,40,'2026-04-21 15:20:26','2026-04-21 15:20:26'),(5,'New Connection Request',1,1,'2026-04-21 15:25:01','2026-04-21 15:25:01'),(6,'New Issue Category',0,0,'2026-04-21 19:35:43','2026-04-21 19:36:03');
/*!40000 ALTER TABLE `support_ticket_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_ticket_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket_companies` (
  `company_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`company_id`),
  UNIQUE KEY `uk_support_ticket_companies_name` (`company_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_ticket_companies` WRITE;
/*!40000 ALTER TABLE `support_ticket_companies` DISABLE KEYS */;
INSERT INTO `support_ticket_companies` VALUES (1,'Friendsonline BD',1,10,'2026-04-24 17:23:59','2026-04-24 17:23:59');
/*!40000 ALTER TABLE `support_ticket_companies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_ticket_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket_notes` (
  `ticket_note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) unsigned NOT NULL,
  `note_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_note_id`),
  KEY `idx_support_ticket_notes_ticket` (`ticket_id`),
  KEY `idx_support_ticket_notes_status` (`status`),
  KEY `idx_support_ticket_notes_creator` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_ticket_notes` WRITE;
/*!40000 ALTER TABLE `support_ticket_notes` DISABLE KEYS */;
INSERT INTO `support_ticket_notes` VALUES (1,3,'test note for customer 11',NULL,1,'2026-04-21 18:26:40','2026-04-21 18:26:40'),(2,3,'test note',NULL,1,'2026-04-21 18:37:36','2026-04-21 18:37:36'),(3,3,'test note 3',NULL,1,'2026-04-21 18:44:29','2026-04-21 18:44:29'),(4,3,'test',NULL,1,'2026-04-21 18:55:44','2026-04-21 18:55:44'),(5,4,'note teesttttt',NULL,1,'2026-04-21 19:00:37','2026-04-21 19:00:37'),(6,4,'note added',NULL,1,'2026-04-21 19:01:00','2026-04-21 19:01:00');
/*!40000 ALTER TABLE `support_ticket_notes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_ticket_priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket_priorities` (
  `priority_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `priority_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'secondary',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`priority_id`),
  UNIQUE KEY `uk_support_ticket_priorities_name` (`priority_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_ticket_priorities` WRITE;
/*!40000 ALTER TABLE `support_ticket_priorities` DISABLE KEYS */;
INSERT INTO `support_ticket_priorities` VALUES (1,'Low','success',1,10,'2026-04-21 15:20:26','2026-04-21 15:20:26'),(2,'Medium','warning',1,20,'2026-04-21 15:20:26','2026-04-21 15:20:26'),(3,'High','danger',1,30,'2026-04-21 15:20:26','2026-04-21 15:20:26'),(4,'Critical','dark',1,40,'2026-04-21 15:20:26','2026-04-21 15:20:26');
/*!40000 ALTER TABLE `support_ticket_priorities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_ticket_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket_statuses` (
  `ticket_status_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'secondary',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_status_id`),
  UNIQUE KEY `uk_support_ticket_statuses_name` (`status_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_ticket_statuses` WRITE;
/*!40000 ALTER TABLE `support_ticket_statuses` DISABLE KEYS */;
INSERT INTO `support_ticket_statuses` VALUES (1,'Open','success',1,10,'2026-04-21 15:20:26','2026-04-24 16:14:24'),(2,'In Progress','primary',1,20,'2026-04-21 15:20:26','2026-04-21 15:20:26'),(3,'Pending','warning',1,30,'2026-04-21 15:20:26','2026-04-21 15:20:26'),(4,'Closed','secondary',1,40,'2026-04-21 15:20:26','2026-04-21 15:20:26');
/*!40000 ALTER TABLE `support_ticket_statuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_tickets` (
  `ticket_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ticket_for` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'existing_customer',
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `company_id` bigint(20) unsigned DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `issue_details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `priority_id` bigint(20) unsigned DEFAULT NULL,
  `ticket_status_id` bigint(20) unsigned DEFAULT NULL,
  `assigned_employee_id` bigint(20) unsigned DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `uk_support_tickets_ticket_no` (`ticket_no`),
  KEY `idx_support_tickets_status` (`status`),
  KEY `idx_support_tickets_ticket_status` (`ticket_status_id`),
  KEY `idx_support_tickets_priority` (`priority_id`),
  KEY `idx_support_tickets_assigned` (`assigned_employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
INSERT INTO `support_tickets` VALUES (1,'TKT-20260421153841-724','existing_customer',1,NULL,NULL,'test 2',2,3,2,1,1,NULL,NULL,'2026-04-21 15:38:41','2026-04-21 15:38:41'),(2,'TKT-20260421155440-884','existing_customer',1,NULL,NULL,'issue 3',2,2,2,1,0,NULL,NULL,'2026-04-21 15:54:40','2026-04-21 16:10:38'),(3,'TKT-20260421170120-111','existing_customer',1,NULL,NULL,'Search by username or phone from the dropdown. Search by username or phone from the dropdown.Search by username or phone from the dropdown.S earch by username or phone from the dropdown.Search by username or phone from the dropdown.',3,1,3,1,1,NULL,NULL,'2026-04-21 17:01:20','2026-04-21 18:59:31'),(4,'TKT-20260421185812-187','existing_customer',1,NULL,NULL,'test isssuueriejewk',2,3,2,1,1,NULL,NULL,'2026-04-21 18:58:12','2026-04-21 18:58:12'),(5,'TKT-20260424162659-706','existing_customer',1,NULL,NULL,'test issue 24 april',2,3,1,1,1,1,NULL,'2026-04-24 16:26:59','2026-04-24 16:26:59'),(6,'TKT-20260424172418-508','existing_customer',1,1,1,'test issue24 2',5,3,1,1,1,1,NULL,'2026-04-24 17:24:18','2026-04-24 17:24:18'),(7,'TKT-20260424174814-756','existing_customer',1,1,1,'ttessss',3,1,1,1,1,1,NULL,'2026-04-24 17:48:14','2026-04-24 17:48:14');
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

